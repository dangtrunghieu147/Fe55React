import "./App.css";
import ShoppingHome from "./shoppingCart";
// import ExerciseMovieList from "./ExMovies";
// import ExerciseChangeCarColor from "./ExCars";
// import DemoDatabinding from "./Databinding";
// import HomeEx2 from "./ex-2/Home";
// import Homepage from "./pages/index";
// import Contactpage from "./pages/contact";
// import HomeEx1 from "./ex-1";

function App() {
  return (
    <div className="App">
      {/* <Homepage /> */}
      {/* <Contactpage /> */}
      {/* <HomeEx1 /> */}
      {/* <HomeEx2 /> */}
      {/* <DemoDatabinding /> */}
      {/* <ExerciseChangeCarColor /> */}
      {/* <ExerciseMovieList /> */}
      <ShoppingHome />
    </div>
  );
}

export default App;
