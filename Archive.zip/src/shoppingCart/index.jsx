import React, { Component, Fragment } from "react";
import Cart from "./cart";
import Detail from "./detail";
import Header from "./header";
import ProductList from "./productList";

class ShoppingHome extends Component {
  render() {
    return (
      <>
        <Header />
        <ProductList />
        <Detail />
        <Cart />
      </>
    );
  }
}

export default ShoppingHome;
