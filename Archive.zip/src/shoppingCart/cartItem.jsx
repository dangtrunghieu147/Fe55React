import React, { Component } from "react";

class CartItem extends Component {
  render() {
    return (
      <tr>
        <td>1</td>
        <td>
          <img src="" alt="product" />
        </td>
        <td>Iphone 12 promax</td>
        <td>
          <button className="btn btn-info">+</button>1
          <button className="btn btn-info">-</button>
        </td>
        <td>90000</td>
        <td>12000</td>
      </tr>
    );
  }
}

export default CartItem;
