import React, { Component } from "react";

class Detail extends Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-4">
            <h1>Iphone 12 pro max</h1>
            <img src="" alt="product" />
          </div>
          <div className="col-8">
            <h1>Thông số kĩ thuật</h1>
            <table className="table">
              <tr>
                <td>Màn hình</td>
                <td>6.1inch</td>
              </tr>
              <tr>
                <td>Camera trước</td>
                <td>6.1inch</td>
              </tr>
              <tr>
                <td>Camera sau</td>
                <td>6.1inch</td>
              </tr>
              <tr>
                <td>Giá</td>
                <td>12,000,000 VND</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default Detail;
