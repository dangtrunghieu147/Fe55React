import React, { Component } from "react";

class ProductItem extends Component {
  render() {
    return (
      <div className="card">
        <img src="" alt="product" />
        <div className="card-body">
          <p className="lead font-weight-bold">Iphone 12 pro max</p>
          <button className="btn btn-success">Xem chi tiết</button>
          <button className="btn btn-info">Thêm giỏ hàng</button>
        </div>
      </div>
    );
  }
}

export default ProductItem;
