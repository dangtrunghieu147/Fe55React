import React from "react";
import Header from "../components/header";

class Contact extends React.Component {
  render() {
    return (
      <div>
        <Header />
        <h1>Dích i contact page</h1>
        <p>Contact to me</p>
      </div>
    );
  }
}

export default Contact;
