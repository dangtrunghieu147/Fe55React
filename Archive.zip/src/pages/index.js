import React from "react";
import Header from "../components/header";

class Home extends React.Component {
  render() {
    return (
      <div>
        <Header />
        <h1>Dích y Home</h1>

        <p>Home page</p>
      </div>
    );
  }
}

export default Home;
