import React, { Component } from "react";

class Sidebar extends Component {
  render() {
    return <div className="bg-info">Sidebar</div>;
  }
}

export default Sidebar;
