import React, { Component } from "react";

class Content extends Component {
  render() {
    return <div className="bg-warning">content</div>;
  }
}

export default Content;
