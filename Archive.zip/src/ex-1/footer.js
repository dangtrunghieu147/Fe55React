import React, { Component } from "react";

class Footer extends Component {
  render() {
    return <div className="bg-dark">Footer</div>;
  }
}

export default Footer;
